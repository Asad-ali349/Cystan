<?php 

include("../../db/conn.php"); 
if (isset($_POST['submit'])) {

    $f_name=$_POST['f_name'];
    $f_postal=$_POST['f_postal'];
    $f_address=$_POST['f_address'];
    $f_security=$_POST['f_security'];
    $f_email=$_POST['f_email'];

    $t_name=$_POST['t_name'];
    $t_postal=$_POST['t_postal'];
    $t_address=$_POST['t_address'];
    $t_url=$_POST['t_url'];
    $t_phone=$_POST['t_phone'];

    $comp_name=$_POST['cname'];
    
    $add_letter=mysqli_query($conn,"INSERT INTO `letter`(`f_name`, `f_postal_address`, `f_address`, `f_security`, `f_email`, `t_name`, `t_postal_address`, `t_address`, `t_url`, `phone`, `company`) VALUES('$f_name','$f_postal','$f_address','$f_security','$f_email','$t_name','$t_postal','$t_address','$t_url','$t_phone','$comp_name')");
    if ($add_letter) {
        $get_id=mysqli_fetch_array(mysqli_query($conn,"SELECT id from letter WHERE `f_name`='$f_name' AND `f_postal_address`='$f_postal' AND `f_address`='$f_address' AND `f_security`='$f_security' AND `f_email`='$f_email' AND`t_name`='$t_name' AND `t_postal_address`= '$t_postal' AND `t_address`='$t_address' AND `t_url`='$t_url' AND `phone`='$t_phone' AND `company`='$comp_name'"));
            $lid=$get_id['id'];
         if (isset($_POST['inq'])) {
            foreach($_POST['inq'] as $key=>$val){
                $inq= $_POST['inq'][$key];
                $allegation=mysqli_query($conn,"INSERT INTO allegations(letter_id,allegation)VALUES ('$lid','$inq')");
            }
            if ($add_letter==true && $allegation==true) {
                 header("Location: letter_preview.php?id=$lid");

            }
        }
    }else{
        echo "Error: ".$conn->error;
    }

}

 ?>


<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, shrink-to-fit=no">
    <title>Invoice Add | CORK - Multipurpose Bootstrap Dashboard Template </title>
    <link rel="icon" type="image/x-icon" href="assets/img/favicon.ico"/>
    <!-- BEGIN GLOBAL MANDATORY STYLES -->
    <link href="https://fonts.googleapis.com/css?family=Nunito:400,600,700" rel="stylesheet">
    <link href="bootstrap/css/bootstrap.min.css" rel="stylesheet" type="text/css" />
    <link href="assets/css/plugins.css" rel="stylesheet" type="text/css" />
    <link href="plugins/perfect-scrollbar/perfect-scrollbar.css" rel="stylesheet" type="text/css" />
    <!-- END GLOBAL MANDATORY STYLES -->

    <!--  BEGIN CUSTOM STYLE FILE  -->
    <link href="assets/css/apps/invoice-add.css" rel="stylesheet" type="text/css" />
    <link rel="stylesheet" type="text/css" href="plugins/dropify/dropify.min.css">
    <link rel="stylesheet" type="text/css" href="assets/css/forms/theme-checkbox-radio.css">
    <link href="plugins/flatpickr/flatpickr.css" rel="stylesheet" type="text/css">
    <link href="plugins/flatpickr/custom-flatpickr.css" rel="stylesheet" type="text/css">
    <link rel="stylesheet" href="plugins/font-icons/fontawesome/css/regular.css">
    <link rel="stylesheet" href="plugins/font-icons/fontawesome/css/fontawesome.css">
    <link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css" integrity="sha384-AYmEC3Yw5cVb3ZcuHtOA93w35dYTsvhLPVnYs9eStHfGJvOvKxVfELGroGkvsg+p" crossorigin="anonymous"/>
    <link rel="stylesheet" type="text/css" href="signature_assets/css/jquery_signature.css">
    <!--  END CUSTOM STYLE FILE  -->
    
</head>
<body>
    <!--  BEGIN NAVBAR  -->
    <!-- <?php include_once("../includes/topbar.php") ?> -->
    <!--  END NAVBAR  -->

    <!--  BEGIN MAIN CONTAINER  -->
    <div class="main-container" id="container">

        <?php   include_once("../includes/sidenav.php") ?>
        <!--  END SIDEBAR  -->

        <!--  BEGIN CONTENT AREA  -->
        <div id="content" class="main-content">
            <div class="layout-px-spacing">

                <div class="row invoice layout-top-spacing layout-spacing">
                    <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                        
                        <div class="doc-container">

                            <div class="row">
                                <div class="col-xl-12">
                                    <form action="" method="POST">
                                        <div class="invoice-content">

                                            <div class="invoice-detail-body">

                                               

                                                <div class="invoice-detail-header">

                                                    <div class="row justify-content-between">
                                                        <div class="col-xl-5 invoice-address-company">

                                                            <h4>To:-</h4>

                                                            <div class="invoice-address-company-fields">

                                                                <div class="form-group row">
                                                                    <label for="company-name" class="col-sm-3 col-form-label col-form-label-sm">Name</label>
                                                                    <div class="col-sm-9">
                                                                        <input type="text" class="form-control form-control-sm" id="company-name" name="t_name" placeholder="Business Name">
                                                                    </div>
                                                                </div>

                                                                <div class="form-group row">
                                                                    <label for="company-email" class="col-sm-3 col-form-label col-form-label-sm">Postal Address</label>
                                                                    <div class="col-sm-9">
                                                                        <input type="text" class="form-control form-control-sm" id="company-email" name="t_postal" placeholder="PO Box 740241 ">
                                                                    </div>
                                                                </div>

                                                                <div class="form-group row">
                                                                    <label for="company-address" class="col-sm-3 col-form-label col-form-label-sm">Address</label>
                                                                    <div class="col-sm-9">
                                                                        <input type="text" class="form-control form-control-sm" id="company-address" name="t_address" placeholder="Atlanta, GA 30374-0256">
                                                                    </div>
                                                                </div>

                                                                <div class="form-group row">
                                                                    <label for="company-phone" class="col-sm-3 col-form-label col-form-label-sm">Url</label>
                                                                    <div class="col-sm-9">
                                                                        <input type="url" class="form-control form-control-sm" id="company-phone" name="t_url" placeholder="https//www.example.com">
                                                                    </div>
                                                                </div> 
                                                                <div class="form-group row">
                                                                    <label for="company-phone" class="col-sm-3 col-form-label col-form-label-sm">Phone</label>
                                                                    <div class="col-sm-9">
                                                                        <input type="" class="form-control form-control-sm" id="company-phone" name="t_phone" placeholder="(123) 456 789">
                                                                    </div>
                                                                </div>                                                                
                                                                
                                                            </div>
                                                            
                                                        </div>
                                                    </div>
                                                    
                                                </div>

                                                <div class="invoice-detail-terms">

                                                    <div class="row justify-content-between">
                                                        <div class="col-md-12">
                                                            <div class="row">
                                                                <div class="col-md-2 mt-4">
                                                                    <label>Company Name</label>
                                                                </div>
                                                                <div class="col-md-4 mt-4" >

                                                                    <input type="text"  placeholder="Company"  name="cname" class="form-control form-control-sm">
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="col-md-9 mt-3"><h4>Add inquiries</h4></div>
                                                        <div class="col-md-3 mt-3">
                                                            <button type="button" class="btn btn-primary" id="click"name="inquiries"> <li class="fa fa-plus"></li></button>
                                                        </div>
                                                        <div class="col-md-12" id="body">

                                                        </div>
                                                        
                                                        

                                                    </div>
                                                    
                                                </div>

                                                <div class="invoice-detail-header mt-5 invoice-detail-terms" >

                                                    <div class="row justify-content-between">
                                                        <div class="col-xl-5 invoice-address-company">

                                                            <h4 class="mt-3">From:-</h4>

                                                             <div class="invoice-address-company-fields">

                                                                <div class="form-group row">
                                                                    <label for="company-name" class="col-sm-3 col-form-label col-form-label-sm">Name</label>
                                                                    <div class="col-sm-9">
                                                                        <input type="text" class="form-control form-control-sm" id="company-name" name="f_name" placeholder="Business Name">
                                                                    </div>
                                                                </div>

                                                                <div class="form-group row">
                                                                    <label for="company-email" class="col-sm-3 col-form-label col-form-label-sm">Postal Address</label>
                                                                    <div class="col-sm-9">
                                                                        <input type="text" class="form-control form-control-sm" id="company-email" name="f_postal" placeholder="PO Box 740241 ">
                                                                    </div>
                                                                </div>

                                                                <div class="form-group row">
                                                                    <label for="company-address" class="col-sm-3 col-form-label col-form-label-sm">Address</label>
                                                                    <div class="col-sm-9">
                                                                        <input type="text" class="form-control form-control-sm" id="company-address" name="f_address" placeholder="Atlanta, GA 30374-0256">
                                                                    </div>
                                                                </div>

                                                                <div class="form-group row">
                                                                    <label for="company-phone" class="col-sm-3 col-form-label col-form-label-sm">Security#</label>
                                                                    <div class="col-sm-9">
                                                                        <input type="url" class="form-control form-control-sm" id="company-phone" name="f_security" placeholder="Security#">
                                                                    </div>
                                                                </div> 
                                                                <div class="form-group row">
                                                                    <label for="company-phone" class="col-sm-3 col-form-label col-form-label-sm">Email</label>
                                                                    <div class="col-sm-9">
                                                                        <input type="" class="form-control form-control-sm" id="company-phone" name="f_email" placeholder="john@example.com">
                                                                    </div>
                                                                </div>                                                                
                                                                
                                                            </div>
                                                            
                                                        </div>


                                                       
                                                    </div>
                                                        <center><button type="submit" name="submit" class="btn-primary btn ">Create</button></center>
                                                </div>
                                            </div>
                                            
                                        </div>
                                    </form>
                                    
                                </div>

                               
                            </div>
                            
                            
                        </div>

                    </div>
                </div>
            </div>
            <div class="footer-wrapper">
                <div class="footer-section f-section-1">
                    <p class="">Copyright © 2021 <a target="_blank" href="https://designreset.com">DesignReset</a>, All rights reserved.</p>
                </div>
                <div class="footer-section f-section-2">
                    <p class="">Coded with <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-heart"><path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"></path></svg></p>
                </div>
            </div>
        </div>
        <!--  END CONTENT AREA  -->

    </div>
    <!-- END MAIN CONTAINER -->

    <!-- BEGIN GLOBAL MANDATORY SCRIPTS -->
    <script src="assets/js/libs/jquery-3.1.1.min.js"></script>
    <script src="bootstrap/js/popper.min.js"></script>
    <script src="bootstrap/js/bootstrap.min.js"></script>
    <script src="plugins/perfect-scrollbar/perfect-scrollbar.min.js"></script>
    <script src="assets/js/app.js"></script>
    
    <script>
        $(document).ready(function() {
            App.init();
        });
    </script>
    <script src="assets/js/custom.js"></script>
    <!-- END GLOBAL MANDATORY SCRIPTS -->

    <script src="plugins/dropify/dropify.min.js"></script>
    <script src="plugins/flatpickr/flatpickr.js"></script>
    <script src="assets/js/apps/invoice-add.js"></script>
    <script>
          

          $(function(){
            var html = '';
            var counter=0;
            $('#click').click(function(){
                   counter++ ;
                 
                  html = '<div class="row mt-2" id="'+counter+'">'+
                            '<div class="col-sm-9">'+
                            '  <input type="text" class="form-control" name="inq[]" placeholder="Enter inquiries" style="width:100%"  required>'+
                            '</div>'+
                            ' <div class="col-sm-3">'+
                            '  <button type="button" class="btn btn-danger" onclick="deleterow('+counter+')"  ><li class="fa fa-times"></li></button>'+
                           ' </div>'+
                         '</div> ';
                  $('#body').append(html)
            })
          })

          function deleterow(id){
             
            $('#'+id).remove()

          }
         
        </script>
</body>
</html>