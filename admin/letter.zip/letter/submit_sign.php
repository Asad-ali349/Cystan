<?php 
include("../../db/conn.php");
session_start();
$response=['error'=>true];

if (isset($_POST['sign']) &&isset($_POST['lid'])&&isset($_POST['page'])) {
    $sign=$_POST['sign'];
    $lid=$_POST['lid'];
    $page=$_POST['page'];
    $add_sign=mysqli_query($conn,"UPDATE letter SET signature='$sign' WHERE id='$lid'");
    if ($add_sign==true) {
        $_SESSION['msg']="added";
        header("Location: ".$page); 
    }else{
        $_SESSION['msg']="error";
        header("Location: ".$page); 
    }

}
 ?>}
